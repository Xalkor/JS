Put image file that you want to filter into the resources folder
and type its name (eg. fileName.extention) in the first line of the
input file. Then run filter.jar and your filtered image will be named 
'fileName2.extention'. filter.jar and the resources folder must be
located in the same directory, at the same level. 